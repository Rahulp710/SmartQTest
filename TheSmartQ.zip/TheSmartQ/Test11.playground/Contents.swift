import UIKit

var str = "Hello, playground"


func IsItemAvailable(_ itemName: String, and timestring: String ) -> String {
    let arr = timestring.components(separatedBy: ",")
    let currentDate = createDateFromString(getCurrentDate())!
    for timeS in arr {
        let startNStopTime = timeS.components(separatedBy: "-")
        if let startDateString = startNStopTime.first,
            let startDate = createDateFromString(startDateString),
            let lastDateString = startNStopTime.last,
            let lastDate = createDateFromString(lastDateString) {
            if currentDate > startDate && currentDate < lastDate {
                return "\(itemName) available"
            }
        }
    }
    return "\(itemName) unavailable"
}


func createDateFromString(_ string: String) -> Date? {
    let df = DateFormatter()
    df.dateFormat = "HH:mm"
    return df.date(from: string)
}

func getCurrentDate() -> String {
    let date = Date()
    let df = DateFormatter()
    df.dateFormat = "HH:mm"
    return df.string(from: date)
}

print(IsItemAvailable("Dosa", and: "17:00-21:00,7:00-10:00,10:45-12:00"))


