//
//  UserCollectionViewCell.swift
//  Test12
//
//  Created by Rahul Sharma on 06/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import UIKit

class UserCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    
    func updateCell(with user: User) {
        nameLabel.text = "Age: \(user.name ?? "")"
        ageLabel.text = "Age: \(user.age ?? 0)"
        genderLabel.text = "Gender: \(user.gender ?? "")"
    }
}
