//
//  User+CoreDataClass.swift
//  Test12
//
//  Created by Rahul Sharma on 06/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit


@objc(User)
public class User: NSManagedObject {

    class func addUser(_ userDetail: [String: Any]) {
        guard let appDelegate =
           UIApplication.shared.delegate as? AppDelegate,
            let name = userDetail["name"] as? String,
            let age = userDetail["age"] as? Int,
            let gender = userDetail["gender"] as? String else {
                return
        }
        
        let managedContext =
          appDelegate.persistentContainer.viewContext

        let entity =
          NSEntityDescription.entity(forEntityName: "User",
                                     in: managedContext)!
        
        let user = NSManagedObject(entity: entity,
                                     insertInto: managedContext)
        
        user.setValue(name, forKeyPath: "name")
        user.setValue(age, forKeyPath: "age")
        user.setValue(gender, forKeyPath: "gender")

        do {
          try managedContext.save()
        } catch let error as NSError {
          print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    class func getAllUsers() -> [User] {
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
            return [User]()
        }
        
        let managedContext =
          appDelegate.persistentContainer.viewContext
        
        //2
        let fetchRequest =
          NSFetchRequest<NSManagedObject>(entityName: "User")
        
        //3
        do {
            guard let users = try managedContext.fetch(fetchRequest) as? [User] else { return [User]() }
            return users
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
        return [User]()
    }
}
