//
//  ViewController.swift
//  Test12
//
//  Created by Rahul Sharma on 06/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var users = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loaduserDetails()
        getAllusers()
    }
    
    func loaduserDetails() {
        let userDetail = ["name": "Test", "age": 10, "gender": "male"] as [String : Any]
        User.addUser(userDetail)
    }

    func getAllusers() {
        users = User.getAllUsers()
        collectionView.reloadData()
    }
}

extension ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return users.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.item < users.count,
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: String(describing: UserCollectionViewCell.self), for: indexPath) as? UserCollectionViewCell {
            let user = users[indexPath.item]
            cell.updateCell(with: user)
            cell.backgroundColor = .systemFill
            return cell
        }
        return UICollectionViewCell()
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
     func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CGFloat.random(in: 100...200), height: CGFloat.random(in: 100...200))
    }

}
