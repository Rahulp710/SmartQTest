//
//  User+CoreDataProperties.swift
//  Test12
//
//  Created by Rahul Sharma on 06/06/20.
//  Copyright © 2020 Rahul Patil. All rights reserved.
//
//

import Foundation
import CoreData


extension User {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
        return NSFetchRequest<User>(entityName: "User")
    }

    @NSManaged public var name: String?
    @NSManaged public var age: Int16
    @NSManaged public var gender: String?

}
